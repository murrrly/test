// Загрузка котов с сервера
fetch('/api/cats')
    .then(response => response.json())
    .then(cats => {
        const container = document.getElementById('cats-container');
        cats.forEach(cat => {
            container.innerHTML += `
                <div class="cat-card">
                    <img src="${cat.photo_url}" alt="${cat.name}">
                    <h3>${cat.name}</h3>
                    <p>${cat.description}</p>
                </div>
            `;
        });
    });