console.log('Кнопка выхода 1:', document.getElementById('logout-btn'));
console.log('Кнопка выхода 2:', document.getElementById('logout-btn-2'));
// Открытие модальных окон
document.getElementById('login-btn').addEventListener('click', () => {
  document.getElementById('login-modal').style.display = 'block';
});

document.getElementById('register-btn').addEventListener('click', () => {
  document.getElementById('register-modal').style.display = 'block';
});

// Закрытие модалок
document.querySelectorAll('.close').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.modal').forEach(modal => {
      modal.style.display = 'none';
    });
  });
});

// Логин
document.getElementById('login-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const email = e.target.querySelector('input[type="email"]').value;
  const password = e.target.querySelector('input[type="password"]').value;

  const response = await fetch('/api/auth/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, password })
  });

  const data = await response.json();
  if (response.ok) {
    localStorage.setItem('token', data.token);
    alert('Вы успешно вошли!');
    window.location.reload();
  } else {
    alert(data.error || 'Ошибка входа');
  }
});

// Регистрация (исправленная версия)
document.getElementById('register-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const form = e.target; // Перенесено выше использования
  form.classList.add('loading'); // Теперь form определена
  
  const formData = {
    name: form.querySelector('input[type="text"]').value,
    email: form.querySelector('input[type="email"]').value,
    password: form.querySelector('input[type="password"]').value
  };
  console.log('Отправляемые данные:', formData);

  try {
    const response = await fetch('/api/auth/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(formData)
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      throw new Error(errorData.message || `Ошибка сервера: ${response.status}`);
  
    }

    const data = await response.json();
    localStorage.setItem('token', data.token);
    alert(`Регистрация успешна! Добро пожаловать, ${data.user.name}!`);
    window.location.reload();
  } catch (err) {
    console.error('Ошибка регистрации:', err);
    alert(`Ошибка: ${err.message}\nПроверьте введенные данные и попробуйте снова.`);
  } finally {
    form.classList.remove('loading');
  }
});

// Логаут
document.getElementById('logout-btn').addEventListener('click', () => {
  localStorage.removeItem('token');
  window.location.reload();
});

function showUserInfo(user) {
  const userInfo = document.querySelector('.user-info');
  const currentUser = document.getElementById('current-user');

  const token = localStorage.getItem('token');
  const payload = JSON.parse(atob(token.split('.')[1]));
  currentUser.textContent = `Привет, ${payload.name}!`;
  userInfo.style.display = 'block';
  document.getElementById('login-btn').style.display = 'none';
  document.getElementById('register-btn').style.display = 'none';
}


// Проверяем авторизацию при загрузке
function checkAuth() {
  const token = localStorage.getItem('token');
  if (token) {
    try {
      const userData = JSON.parse(atob(token.split('.')[1]));
      showUserInfo(userData);
    } catch (e) {
      console.error('Ошибка чтения токена:', e);
    }
  }
}

// Функция выхода
function logout() {
  localStorage.removeItem('token');
  
  // Скрываем информацию о пользователе
  document.querySelector('.user-info').style.display = 'none';
  
  // Показываем кнопки входа/регистрации
  document.getElementById('login-btn').style.display = 'block';
  document.getElementById('register-btn').style.display = 'block';
  
  // Скрываем кнопки выхода
  document.getElementById('logout-btn').style.display = 'none';
  document.getElementById('logout-btn-2').style.display = 'none';
  
  alert('Вы успешно вышли из системы');
}

// Назначаем обработчики на обе кнопки выхода
document.getElementById('logout-btn')?.addEventListener('click', logout);
document.getElementById('logout-btn-2')?.addEventListener('click', logout);
// Вызываем при загрузке страницы
document.addEventListener('DOMContentLoaded', checkAuth);