document.addEventListener('DOMContentLoaded', () => {
  const bookingForm = document.getElementById('booking-form');
  
  if (!bookingForm) {
    console.error('Форма бронирования не найдена!');
    return;
  }

  bookingForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const token = localStorage.getItem('token');
    if (!token) {
      alert('Пожалуйста, войдите в систему для бронирования');
      document.getElementById('login-btn').click();
      return;
    }

    // Получаем элементы формы безопасным способом
    const getValue = (id) => {
      const el = document.getElementById(id);
      return el ? el.value : null;
    };

    const formData = {
      client_name: getValue('client_name'),
      phone: getValue('phone'),
      booking_date: getValue('booking_date'),
      booking_time: getValue('booking_time'),
      guests: getValue('guests'),
      cat_id: null // У вас пока нет поля выбора кота
    };

    // Валидация
    if (!formData.client_name || !formData.phone || 
        !formData.booking_date || !formData.booking_time || !formData.guests) {
      alert('Заполните все обязательные поля!');
      return;
    }

    try {
      const response = await fetch('/api/bookings', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify(formData)
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || 'Ошибка бронирования');
      }

      const data = await response.json();
      alert(`Столик успешно забронирован! Номер: ${data.id}`);
      bookingForm.reset();
      
    } catch (err) {
      console.error('Ошибка бронирования:', err);
      alert(err.message);
    }
  });
});