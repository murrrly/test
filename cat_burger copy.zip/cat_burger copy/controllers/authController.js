const User = require('../models/User');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken'); // Добавьте эту строку!
const config = require('../config/db');
const { pool } = require('../config/db'); // Используем pool из config/db.js

exports.register = async (req, res) => {
  try {
    const { email, password, name } = req.body;
    
    // Проверка существующего пользователя
    const existingUser = await User.findByEmail(email);
    if (existingUser) {
      return res.status(400).json({ error: 'Пользователь с таким email уже существует' });
    }

    const userId = await User.create(email, password, name);
    const token = jwt.sign(
      { id: user.id },
      config.jwtSecret, // Используем единый ключ
      { expiresIn: '24h' }
    );
    res.status(201).json({ 
      token,
      user: { id: userId, email, name }
    });
  } catch (err) {
    res.status(500).json({ error: 'Ошибка регистрации' });
  }
};

exports.login = async (req, res) => {
  try {
    const { email, password } = req.body;
    
    // 1. Ищем пользователя
    const [users] = 
    await pool.query('SELECT * FROM users WHERE email = ?', [email]);
    
    if (users.length === 0) {
      return res.status(401).json({ error: 'Неверный email или пароль' });
    }

    const user = users[0];
    
    // 2. Проверяем пароль
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(401).json({ error: 'Неверный email или пароль' });
    }

    // 3. Генерируем токен
    const token = jwt.sign(
      { id: user.id },
      config.jwtSecret, // Используем единый ключ
      { expiresIn: '24h' }
    );

    res.json({ 
      token,
      user: { id: user.id, email: user.email, name: user.name }
    });

  } catch (err) {
    console.error('Ошибка входа:', err); // Важно!
    res.status(500).json({ error: 'Ошибка сервера' });
  }
};

exports.getMe = async (req, res) => {
  try {
    const [user] = await pool.query(
      'SELECT id, email, name FROM users WHERE id = ?',
      [req.user.id]
    );
    res.json(user[0]);
  } catch (err) {
    res.status(500).json({ error: 'Ошибка сервера' });
  }
};