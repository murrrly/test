const jwt = require('jsonwebtoken');
const config = require('../config/db');

module.exports = (req, res, next) => {
  const token = req.header('Authorization')?.replace('Bearer ', '') || 
                req.cookies?.token || 
                req.headers.authorization?.replace('Bearer ', '');
  console.log('Получен токен:', token); // Добавьте эту строку
  
  if (!token) {
    return res.status(401).json({ error: 'Требуется авторизация' });
  }

  try {
    const decoded = jwt.verify(token, config.jwtSecret);
    req.user = {
      id: decoded.id,
      name: decoded.name,  // Теперь будет доступно
      email: decoded.email // И это тоже
    };
    console.log('Декодированный пользователь:', req.user); // Для отладки
    next();
  } catch (err) {
    console.log('Неверный токен:', err.message);
    res.status(401).json({ error: 'Неверный токен' });
  }
};