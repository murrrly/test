
const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const authController = require('../controllers/authController');
const authMiddleware = require('../middleware/auth');
const { pool, jwtSecret } = require('../config/db');
const User = require('../models/User');


router.post('/register', async (req, res) => {
  try {
    const { email, password, name } = req.body;
    
    // 1. Валидация (должна быть ПЕРВОЙ)
    if (!name || !email || !password) {
      return res.status(400).json({ error: 'Все поля обязательны' });
    }

    // 2. Проверка существующего пользователя
    const [existing] = await pool.query(
      'SELECT id FROM users WHERE email = ?', 
      [email]
    );
    
    if (existing.length > 0) {
      return res.status(400).json({ error: 'Email уже используется' });
    }

    // 3. Создаем пользователя (используем модель User)
    const userId = await User.create(email, password, name);
    
    // 4. Получаем данные созданного пользователя
    const user = await User.findById(userId);
    
    // 5. Генерируем токен
    const token = User.generateToken(user);
    
    // 6. Отправляем ответ ОДИН РАЗ
    res.json({ 
      token,
      user: {
        id: user.id,
        name: user.name,
        email: user.email
      }
    });

  } catch (err) {
    console.error('Ошибка регистрации:', err);
    res.status(500).json({ error: 'Ошибка сервера при регистрации' });
  }
});

router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    const user = await User.findByEmail(email);
    
    if (!user) {
      return res.status(401).json({ error: 'Пользователь не найден' });
    }
    
    const isMatch = await User.comparePassword(password, user.password);
    if (!isMatch) {
      return res.status(401).json({ error: 'Неверный пароль' });
    }
    
    const token = User.generateToken({
      id: user.id,
      email: user.email,
      name: user.name
    });
    
    res.json({ 
      token,
      user: {
        id: user.id,
        name: user.name,
        email: user.email
      }
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.get('/me', authMiddleware, authController.getMe);


module.exports = router;