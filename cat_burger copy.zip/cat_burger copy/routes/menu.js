const express = require('express');
const { pool } = require('../config/db'); 
const router = express.Router();

// Получить все пункты меню
router.get('/', async (req, res) => {
  try {
    const [menuItems] = await pool.query('SELECT * FROM menu_items');
    res.json(menuItems);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Добавить новый пункт меню
router.post('/', async (req, res) => {
  const { name, price, category } = req.body;
  
  try {
    const [result] = await pool.query(
      'INSERT INTO menu_items (name, price, category) VALUES (?, ?, ?)',
      [name, price, category]
    );
    res.status(201).json({ id: result.insertId });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

module.exports = router;