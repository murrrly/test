const express = require('express');
const { pool } = require('../config/db'); 
const router = express.Router();

// Получить всех котов
router.get('/', async (req, res) => {
  try {
    const [cats] = await pool.query('SELECT * FROM cats WHERE is_active = TRUE');
    res.json(cats);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Добавить нового кота
router.post('/', async (req, res) => {
  const { name, age, breed, description } = req.body;
  
  try {
    const [result] = await pool.query(
      'INSERT INTO cats (name, age, breed, description) VALUES (?, ?, ?, ?)',
      [name, age, breed, description]
    );
    res.status(201).json({ id: result.insertId });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

module.exports = router;