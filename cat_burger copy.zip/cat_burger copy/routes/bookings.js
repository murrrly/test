const express = require('express');
const { pool } = require('../config/db'); 
const router = express.Router();
const authMiddleware = require('../middleware/auth'); 

// Теперь этот роут требует авторизации!
router.post('/', authMiddleware, async (req, res) => {
  try {
    const { client_name, phone, booking_date, booking_time, guests, cat_id } = req.body;
    
    // Проверяем наличие обязательных данных
    if (!req.user.name || !req.user.email) {
      throw new Error('Данные пользователя неполные');
    }
    
    // 1. Получаем данные пользователя из токена
    const userId = req.user.id;
    const userEmail = req.user.email;
    const userName = req.user.name;
    console.log('Данные пользователя:', { userId, userEmail, userName }); // Для отладки

    // Валидация данных
    if (!client_name || !phone || !booking_date || !booking_time || !guests) {
      return res.status(400).json({
         error: 'Все обязательные поля должны быть заполнены' });
    }

    
    // Проверяем доступность времени
    const [existing] = await pool.query(
      `SELECT * FROM reservations 
       WHERE date = ? AND time = ?`,
      [booking_date, booking_time]
    );

    if (existing.length > 0) {
      return res.status(400).json({ 
        error: 'Это время уже занято. Пожалуйста, выберите другое время.' 
      });
    }

    // Создаем бронирование
    const [result] = await pool.query(
      `INSERT INTO reservations 
       (user_name, phone, date, time, guests, email) 
       VALUES (?, ?, ?, ?, ?, ?)`,
      [
        req.user.name,
        phone,
        booking_date,
        booking_time,
        guests,
        req.user.email
      ]
    );
    res.json({ 
      success: true,
      message: `Бронирование создано для ${req.user.name}` 
    });
    } catch (err) {
    console.error('Ошибка бронирования:', err);
    res.status(500).json({ 
      error: err.message,
      userData: req.user // Для отладки
    });
  }
});


// Получение бронирований пользователя
router.get('/my', authMiddleware, async (req, res) => {
  try {
    const [bookings] = await pool.query(
      `SELECT id, date, time, guests, email
       FROM reservations 
       WHERE id = ? 
       ORDER BY date DESC`,
      [req.user.id]
    );
    
    res.json(bookings);
  } catch (err) {
    console.error('Ошибка получения бронирований:', err);
    res.status(500).json({ error: 'Ошибка сервера' });
  }
});

// В routes/bookings.js
router.delete('/:id', authMiddleware, async (req, res) => {
  try {
    const [result] = await pool.query(
      `DELETE FROM reservations 
       WHERE id = ? AND user_id = ?`,
      [req.params.id, req.user.id]
    );

    if (result.affectedRows === 0) {
      return res.status(404).json({ error: 'Бронирование не найдено' });
    }

    res.json({ message: 'Бронирование отменено' });
  } catch (err) {
    console.error('Ошибка отмены бронирования:', err);
    res.status(500).json({ error: 'Ошибка сервера' });
  }
});

module.exports = router;
// // Создание бронирования
// router.post('/', async (req, res) => {
//   const { client_name, phone, booking_date, booking_time, guests, cat_id } = req.body;

//   // Валидация данных
//   if (!client_name || !phone || !booking_date || !booking_time || !guests) {
//     return res.status(400).json({ error: 'Все обязательные поля должны быть заполнены' });
//   }

//   try {
//     // Проверяем доступность времени
//     const [existing] = await db.query(
//       `SELECT * FROM reservations 
//        WHERE date = ? AND time = ?`,
//       [booking_date, booking_time]
//     );

//     if (existing.length >= 3) {
//       return res.status(400).json({ 
//         error: 'Это время уже занято. Пожалуйста, выберите другое время.' 
//       });
//     }

//     // Создаем бронирование
//     const [result] = await db.query(
//       `INSERT INTO reservations 
//        (user_name, phone, date, time, guests, cat_id) 
//        VALUES (?, ?, ?, ?, ?, ?)`,
//       [client_name, phone, booking_date, booking_time, guests, cat_id]
//     );

//     res.status(201).json({
//       id: result.insertId,
//       client_name,
//       booking_date,
//       booking_time,
//       guests,
//       cat_id
//     });
//   } catch (err) {
//     console.error('Ошибка бронирования:', err);
//     res.status(500).json({ error: 'Ошибка сервера при бронировании' });
//   }
// });

module.exports = router;