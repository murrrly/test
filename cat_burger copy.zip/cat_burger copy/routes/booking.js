// В booking.js замените обработчик отправки формы на этот код:
form.addEventListener('submit', async (e) => {
  e.preventDefault();
  
  try {
    const response = await fetch('/api/bookings', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${localStorage.getItem('token')}`
      },
      body: JSON.stringify({
        phone: form.phone.value,
        date: form.booking_date.value,
        time: form.booking_time.value,
        guests: form.guests.value
      })
    });

    const result = await response.json();
    
    if (!response.ok) {
      console.error('Детали ошибки:', result);
      throw new Error(result.error || 'Ошибка сервера');
    }

    alert('Бронирование успешно создано!');
    // После успешного входа/регистрации:
    localStorage.setItem('token', newToken); // Используйте токен из последнего ответа сервера
    form.reset();

    
  } catch (err) {
    console.error('Полная ошибка:', err);
    alert('Ошибка: ' + err.message);
  }
});



// document.getElementById('booking-form').addEventListener('submit', async (e) => {
//   e.preventDefault();
  
//   const token = localStorage.getItem('token');
//   if (!token) {
//     alert('Сначала войдите в систему!');
//     return window.location.href = '/login.html';
//     //document.getElementById('login-btn').click();
//     //return;
//   }

//   // Безопасное получение элементов формы
  
//   const formData = {
//     date: e.target.date.value,
//     time: e.target.time.value,
//     guests: e.target.guests.value,
//     email: e.target.email.value
//   };


//   // Валидация обязательных полей
//   if (!formData.client_name || !formData.phone || !formData.booking_date || 
//       !formData.booking_time || !formData.guests) {
//     alert('Заполните все обязательные поля!');
//     return;
//   }

//   try {
//     const response = await fetch('/api/bookings', {
//       method: 'POST',
//       headers: {
//         'Content-Type': 'application/json',
//         'Authorization': `Bearer ${token}`
//       },
//       body: JSON.stringify(formData)
//     });

//     if (!response.ok) {
//       const error = await response.json();
//       throw new Error(error.error || 'Ошибка бронирования');
//     }

//     const data = await response.json();
//     alert(`Бронирование №${data.id} успешно создано!`);
//     window.location.href = '/my-bookings.html';
//     form.reset();
    
//   } catch (err) {
//     console.error('Ошибка бронирования:', err);
//     alert(err.message);
//   }
// });