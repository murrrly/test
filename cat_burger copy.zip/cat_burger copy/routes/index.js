const express = require('express');
const router = express.Router();
const path = require('path');
const restData = require('../data/restaurant.json');

router.get('/', (req, res) => {
    res.render('index', {
        title: restData.name,
        restaurant: restData
    });
});

module.exports = router;