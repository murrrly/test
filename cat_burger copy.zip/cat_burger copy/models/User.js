
const { pool } = require('../config/db'); 
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

class User {
  // Регистрация
  static async create(email, password, name) {
    // Валидация обязательных полей
    if (!email || !password || !name) {
      throw new Error('Все поля (email, password, name) обязательны');
    }

    const hashedPassword = await bcrypt.hash(password, 10);
    const [result] = await pool.query(
      'INSERT INTO users (email, password, name) VALUES (?, ?, ?)',
      [email, hashedPassword, name]
    );
    return result.insertId;
  }

  // Поиск по email
  static async findByEmail(email) {
    const [rows] = await pool.query(
      'SELECT id, email, name, password FROM users WHERE email = ?', 
      [email]
    );
    return rows[0];
  }

  // Сравнение пароля
  static async comparePassword(candidatePassword, hashedPassword) {
    return await bcrypt.compare(candidatePassword, hashedPassword);
  }

  // Генерация JWT (теперь включает email и name)
  static generateToken(user) {
    return jwt.sign(
      {
        id: user.id,
        email: user.email,
        name: user.name
      },
      require('../config/db').jwtSecret,
      { expiresIn: '24h' }
    );
  }

  // Получение пользователя по ID
  static async findById(id) {
    const [rows] = await pool.query(
      'SELECT id, email, name FROM users WHERE id = ?',
      [id]
    );
    return rows[0];
  }
}

module.exports = User;