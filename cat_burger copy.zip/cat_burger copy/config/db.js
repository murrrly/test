
const mysql = require('mysql2/promise');

const config = {
  host: 'localhost',
  user: 'root',
  password: '12345678', // Ваш пароль MySQL
  database: 'sys',
  jwtSecret: 'b052866d1b23b469d9b6ef874ea01ff5ba3196c280ef755327d6250df2a00e01' // Оставьте ваш 64-символьный ключ
};

const pool = mysql.createPool(config);

// Проверка подключения при старте
pool.getConnection()
  .then(conn => {
    console.log('✅ Подключение к MySQL установлено');
    conn.release();
  })
  .catch(err => {
    console.error('❌ Ошибка подключения к MySQL:', err.message);
  });

module.exports = {
  pool, // Экспортируем pool для использования в других файлах
  jwtSecret: config.jwtSecret
};